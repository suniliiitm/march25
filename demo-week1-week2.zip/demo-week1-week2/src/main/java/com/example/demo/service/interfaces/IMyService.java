package com.example.demo.service.interfaces;

public interface IMyService {
	
	public int add(int num1, int num2);

}
