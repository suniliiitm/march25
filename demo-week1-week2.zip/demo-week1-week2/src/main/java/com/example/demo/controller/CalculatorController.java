package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;


//Post "http://localhost:4242/stripe/webhook"

@RestController
@RequestMapping("/calculator")
public class CalculatorController {

	@GetMapping("/add")
	public int add(@RequestParam int a, @RequestParam int b) {
		return a + b;
	}

	@PostMapping("/add-post")
	public int addPost(@RequestParam int a, @RequestParam int b) {
		System.out.println("Running addPost() " + a + " + " + b);
		return a + b;
	}

	@GetMapping("/sub")
	public int subtract(@RequestParam int a, @RequestParam int b) {
		return a - b;
	}

	@GetMapping("/mul")
	public int multiply(@RequestParam int a, @RequestParam int b) {
		return a * b;
	}

	@GetMapping("/div")
	public int divide(@RequestParam int a, @RequestParam int b) {
		return a / b;
	}

	// Add a new endpoint to calculate the remainder of a division operation
	@GetMapping("/mod")
	public int mod(@RequestParam int a, @RequestParam int b) {
		return a % b;
	}

	// Add a new endpoint to calculate the square of a number
	@GetMapping("/square")
	public int square(@RequestParam int a) {
		return a * a;
	}
}

