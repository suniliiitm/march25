package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.MyNum;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@RestController
@RequestMapping("/test")
public class TestController {

	@PostMapping("/mymethod-post/{pv1}/{pv2}/{pv3}")
	public String myMethodMPost(
			@RequestParam(required = false) String param1, 
			@RequestParam(required = false) String param2,
			@PathVariable String pv1, 
			@PathVariable String pv2, 
			@PathVariable String pv3,
			@RequestBody MyNum requestBody) {
		
		System.out.println("Running myMethodPost() - param1:" + param1 + "|param2:" + param2 
				+ "|pv1:" + pv1 + "|pv2:"
				+ pv2 + "|pv3:" + pv3
				+ "|requestBody:" + requestBody);
		
		/*
		MyNum reqAsObjViaJackson = convertJsonToMyNum(requestBody);
		System.out.println("reqAsObj:" + reqAsObjViaJackson);
		
		MyNum reqAsObjViaGson = convertJsonToMyNumUsingGson(requestBody);
		System.out.println("reqAsObjViaGson:" + reqAsObjViaGson);
		*/
		
		return "Hello World - post|param1:" + param1 + "|param2:" + param2 
				+ "|pv1:" + pv1 + "|pv2:" + pv2 + "|pv3:" + pv3
				+ "\n|requestBody:\n" + requestBody;
		
	}
	
	@GetMapping("/mymethod")
	public String myMethod() {
		System.out.println("Running myMethod()");
		return "/index.html";
	}
	
	@GetMapping("/mymethod2")
	public String myMethod2() {
		System.out.println("Running myMethod2()");
		return "Hello World2";
	}
	
	public static MyNum convertJsonToMyNum(String json) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.readValue(json, MyNum.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null in case of an error
        }
    }
	
	public static MyNum convertJsonToMyNumUsingGson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, MyNum.class);
    }
}
