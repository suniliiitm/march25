package com.example.demo.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//Post "http://localhost:4242/stripe/webhook"

@RestController
@RequestMapping("/stripe")
public class StripeWebhookController {

	@PostMapping("/webhook")
	public int addPost(@RequestBody String eventBody) {

		System.out.println("Received event: "
				+ "eventBody:" + eventBody + "\n\n\n");
		
		/*
		 * if eventBody type is checkout.session.completed
		 * then read fields payment_status & status
		 * 
		 * if payment_status is paid and status is complete, means payment is successful
		 * 
		 * write logic to inform merchant about successful payment
		 * 
		 * Then merchant can send the digital goods to customer
		 */
		
		//return a + b;
		return 1;
	}

}
