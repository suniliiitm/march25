package com.example.demo.service.impl;

import java.util.Random;

import org.springframework.stereotype.Service;

import com.example.demo.service.interfaces.IMyService;

@Service
public class MyServiceImpl implements IMyService {
	
	private Random random;
	
	public MyServiceImpl(Random random) {
		System.out.println("MyServiceImpl||Constructor invoked");
		this.random = random;
	}

	@Override
	public int add(int num1, int num2) {
		System.out.println("MyServiceImpl|| add() invoked|num1:" + num1 + "|num2:" + num2);

		int sum = num1 + num2;
		
		System.out.println("MyServiceImpl||sum:" + sum);
		
		System.out.println("MyServiceImpl||hashCode:" + random.hashCode());
		sum = sum + random.nextInt(100);
		
		return sum;
	}

}
